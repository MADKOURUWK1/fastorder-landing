export default function Home() {
  return (
    <main className="p-6 text-right font-sans">
      <h1 className="text-4xl font-bold mb-4">منيو إلكتروني للمطاعم</h1>
      <p className="mb-6">أنشئ منيو إلكتروني وابدأ في استقبال الطلبات بسهولة</p>
      <ul className="list-disc pr-6 space-y-2">
        <li>إضافة وتعديل عدد لا نهائي من الأطباق</li>
        <li>استقبال الطلبات أونلاين</li>
        <li>رسالة تحقق برقم الهاتف قبل الطلب</li>
        <li>دعم فني لتعليم الإضافة والتعديل</li>
        <li>لوحة تحكم سهلة لإدارة الطلبات</li>
        <li>واجهة سهلة للزبائن</li>
        <li>QR كود يعرض المنيو بالأسعار والصور</li>
        <li>عرض الفروع ومناطق التوصيل</li>
      </ul>
    </main>
  )
}