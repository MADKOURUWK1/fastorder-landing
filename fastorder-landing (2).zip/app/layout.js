import './globals.css'

export const metadata = {
  title: 'FastOrder',
  description: 'خدمة المنيو الإلكتروني للمطاعم',
}

export default function RootLayout({ children }) {
  return (
    <html lang="ar" dir="rtl">
      <body>{children}</body>
    </html>
  )
}